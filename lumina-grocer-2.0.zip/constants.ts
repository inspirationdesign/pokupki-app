
import { CategoryDef } from './types';

export const DEFAULT_CATEGORIES: CategoryDef[] = [
  { id: 'dept_produce', name: 'Овощи и Фрукты', emoji: '🥦' },
  { id: 'dept_dairy', name: 'Молочное и Яйца', emoji: '🥛' },
  { id: 'dept_meat', name: 'Мясо и Рыба', emoji: '🥩' },
  { id: 'dept_bakery', name: 'Хлеб и Выпечка', emoji: '🥖' },
  { id: 'dept_grocery', name: 'Бакалея и Консервы', emoji: '🍝' },
  { id: 'dept_frozen', name: 'Заморозка', emoji: '🧊' },
  { id: 'dept_drinks', name: 'Напитки', emoji: '🥤' },
  { id: 'dept_snacks', name: 'Сладости и Снеки', emoji: '🍫' },
  { id: 'dept_pharmacy', name: 'Аптека', emoji: '💊' },
  { id: 'dept_home', name: 'Для дома', emoji: '🏠' },
  { id: 'dept_household', name: 'Бытовая химия', emoji: '🧼' },
  { id: 'dept_personal', name: 'Гигиена и Уход', emoji: '🪥' },
  { id: 'other', name: 'Разное', emoji: '📦' },
  { id: 'dept_none', name: 'Без категории', emoji: '⚪' }
];

export const INITIAL_ITEMS = [];

export const EMOJI_LIST = [
  // Produce & Food
  '🥦','🍅','🌽','🥕','🥔','🍎','🍏','🍐','🍑','🍒','🍓','🫐','🍇','🍉','🍌','🍋','🍊','🍍','🍈','🥥','🥑','🍆','🥒','🥬','🧄','🧅','🍄',
  '🥛','🍼','🧀','🥚','🥩','🍗','🍖','🦴','🥓','🍔','🍟','🍕','🌭','🥪','🌮','🌯','🥙','🍳','🥘','🍲','🥣','🥗','🍿','🍱','🍘','🍣','🍤','🍥','🥠','🥡',
  '🥖','🥐','🍞','🥯','🥨','🥞','🧇','🥧','🧁','🍰','🎂','🍮','🍭','🍬','🍫','🍩','🍪','🍯',
  // Drinks
  '🥤','🧃','🍵','☕','🍼','🍺','🍻','🥂','🍷','🥃','🍸','🍹','🧉','🧊',
  // Pharmacy & Household & Home
  '💊','🩹','🩺','🌡️','🧴','🧼','🧽','🧹','🧺','🧻','🚿','🛀','🪒','🦷','🪥','💄','💅','🪞','🪣','🧤','🫧','🕯️','🔦','🔋',
  '🏠','🪑','🛋️','🛏️','🖼️','🪴','📺','💻','🎮','🔌','🔋','🧯','🧺','🧹','🧹','🧽','🧼','🚪',
  // Pets & Others
  '🐱','🐶','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','👶','🧸','✨','🔥','💡','🛠️','📦'
];

export const GET_CATEGORY_COLOR = (index: number) => {
  const colors = [
    'text-emerald-600 dark:text-emerald-400',
    'text-blue-600 dark:text-blue-400',
    'text-rose-600 dark:text-rose-400',
    'text-amber-600 dark:text-amber-400',
    'text-violet-600 dark:text-violet-400',
    'text-cyan-600 dark:text-cyan-400',
  ];
  return colors[index % colors.length];
};
